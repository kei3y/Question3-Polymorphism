/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionFive;

/**
 *
 * @author Kei3ron
 */
public class carLoanApplication {
    public static void main(String[] args) {
        carLoan carLoan = new carLoan();

        carLoan.setLoanId("CL1225");
        carLoan.setCustName("Kei3ron");
        carLoan.setAmount(6000000);
        carLoan.setCarLien(true);
        
        System.out.println("Loan ID: " + carLoan.getLoanId());
        System.out.println("Customer Name: " + carLoan.getCustName());
        System.out.println("Loan Amount: Ugx" + carLoan.getAmount());
        System.out.println("Loan Type: " + carLoan.getLoanType());
        System.out.println("Car Lien: " + (carLoan.getCarLien() ? "Yes" : "No"));
    }
}