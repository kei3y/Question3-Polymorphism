/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionFive;

/**
 *
 * @author Kei3ron
 */
    abstract class loan {
    private String loan_id;
    private String loan_type;
    private double amount;
    private String cust_name;

    public loan() {
        this.amount = 0;
    }

    public void setLoanId(String loan_id) {
        this.loan_id = loan_id;
    }

    public void setCustName(String cust_name) {
        this.cust_name = cust_name;
    }

    public String getLoanId() {
        return loan_id;
    }

    public String getCustName() {
        return cust_name;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }
    public abstract String getLoanType();
}
