/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionFive;

/**
 *
 * @author Kei3ron
 */
    class carLoan extends loan {
    private boolean car_lien;

    public carLoan() {
        this.setAmount(0);
        this.setLoanId("");
        this.setCustName("");
        this.car_lien = false;
    }

    public void setCarLien(boolean lien) {
        this.car_lien = lien;
    }

    public boolean getCarLien() {
        return car_lien;
    }

    @Override
    public String getLoanType() {
        return "Car Loan";
    }
}
